﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameOfLifeProject
{
    public partial class ModalDialogRandomize : Form
    {
        public ModalDialogRandomize()
        {
            InitializeComponent();
        }

        public decimal Seed
        {
            get
            {
                return numericUpDownSeed.Value;
            }
            set
            {
                numericUpDownSeed.Value = value;
            }
        }
    }
}
